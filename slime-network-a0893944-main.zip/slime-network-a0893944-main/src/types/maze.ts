export type CellType = 'empty' | 'wall' | 'start' | 'end';

export interface Cell {
  row: number;
  col: number;
  type: CellType;
  slimeStrength: number; // 0 to 1
  isExplored: boolean;
  distanceFromStart: number; // for optimization
}

export interface MazeState {
  grid: Cell[][];
  rows: number;
  cols: number;
  startCell: { row: number; col: number } | null;
  endCell: { row: number; col: number } | null;
  phase: 'setup' | 'exploring' | 'reinforcing' | 'optimizing' | 'complete';
  logs: string[];
  shortestPathLength: number | null;
}

export type PlacementMode = 'wall' | 'start' | 'end' | 'erase';
