import React, { useRef, useCallback } from 'react';
import { Node, Path } from '@/types/network';

interface NetworkCanvasProps {
  nodes: Node[];
  paths: Path[];
  phase: string;
  onAddNode: (x: number, y: number) => void;
}

export const NetworkCanvas: React.FC<NetworkCanvasProps> = ({
  nodes,
  paths,
  phase,
  onAddNode,
}) => {
  const canvasRef = useRef<HTMLDivElement>(null);

  const handleClick = useCallback((e: React.MouseEvent<HTMLDivElement>) => {
    if (!canvasRef.current) return;
    
    const rect = canvasRef.current.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    
    onAddNode(x, y);
  }, [onAddNode]);

  const getPathColor = (path: Path) => {
    if (path.isBroken) return 'hsl(0 80% 55%)';
    if (path.isHealing) return 'hsl(280 60% 55%)';
    if (path.strength > 0.7) return 'hsl(35 90% 55%)';
    if (path.strength > 0.4) return 'hsl(145 80% 50%)';
    return 'hsl(160 20% 25%)';
  };

  const getPathWidth = (path: Path) => {
    if (path.isBroken) return 0;
    return Math.max(1, path.strength * 6);
  };

  const findNode = (id: string) => nodes.find(n => n.id === id);

  return (
    <div
      ref={canvasRef}
      onClick={handleClick}
      className="relative w-full h-[500px] bg-background rounded-xl border border-border overflow-hidden cursor-crosshair"
      style={{
        background: 'radial-gradient(ellipse at center, hsl(200 25% 10%), hsl(200 25% 5%))',
      }}
    >
      {/* Grid overlay */}
      <div 
        className="absolute inset-0 opacity-10"
        style={{
          backgroundImage: `
            linear-gradient(hsl(160 20% 30%) 1px, transparent 1px),
            linear-gradient(90deg, hsl(160 20% 30%) 1px, transparent 1px)
          `,
          backgroundSize: '40px 40px',
        }}
      />

      {/* SVG for paths */}
      <svg className="absolute inset-0 w-full h-full pointer-events-none">
        <defs>
          <filter id="glow">
            <feGaussianBlur stdDeviation="3" result="coloredBlur"/>
            <feMerge>
              <feMergeNode in="coloredBlur"/>
              <feMergeNode in="SourceGraphic"/>
            </feMerge>
          </filter>
        </defs>
        
        {paths.map(path => {
          const fromNode = findNode(path.from);
          const toNode = findNode(path.to);
          if (!fromNode || !toNode) return null;
          
          return (
            <line
              key={path.id}
              x1={fromNode.x}
              y1={fromNode.y}
              x2={toNode.x}
              y2={toNode.y}
              stroke={getPathColor(path)}
              strokeWidth={getPathWidth(path)}
              strokeLinecap="round"
              opacity={path.isBroken ? 0.3 : 0.8 + path.strength * 0.2}
              filter={path.strength > 0.5 ? "url(#glow)" : undefined}
              style={{
                transition: 'all 0.3s ease-out',
                strokeDasharray: path.isBroken ? '5,5' : 'none',
              }}
            />
          );
        })}
      </svg>

      {/* Nodes */}
      {nodes.map((node, index) => (
        <div
          key={node.id}
          className="absolute transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300"
          style={{
            left: node.x,
            top: node.y,
          }}
        >
          <div
            className={`
              w-6 h-6 rounded-full 
              ${node.isActive ? 'animate-pulse-glow' : ''}
              ${node.isFood ? 'bg-secondary' : 'bg-accent'}
            `}
            style={{
              boxShadow: node.isActive 
                ? `0 0 20px ${node.isFood ? 'hsl(35 90% 55% / 0.6)' : 'hsl(180 80% 55% / 0.6)'}`
                : 'none',
            }}
          />
          <span className="absolute top-8 left-1/2 -translate-x-1/2 text-xs text-muted-foreground whitespace-nowrap">
            N{index + 1}
          </span>
        </div>
      ))}

      {/* Instructions overlay */}
      {nodes.length === 0 && (
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="text-center text-muted-foreground">
            <p className="text-lg mb-2">Click anywhere to add nodes</p>
            <p className="text-sm opacity-70">Add at least 2 nodes, then click "Start Growth"</p>
          </div>
        </div>
      )}

      {/* Phase indicator */}
      <div className="absolute top-4 right-4 px-3 py-1 rounded-full text-xs font-medium bg-muted/80 backdrop-blur-sm border border-border">
        <span className={`
          inline-block w-2 h-2 rounded-full mr-2
          ${phase === 'idle' ? 'bg-muted-foreground' : ''}
          ${phase === 'exploring' ? 'bg-primary animate-pulse' : ''}
          ${phase === 'reinforcing' ? 'bg-secondary animate-pulse' : ''}
          ${phase === 'stable' ? 'bg-primary' : ''}
          ${phase === 'damaged' ? 'bg-damage animate-pulse' : ''}
          ${phase === 'healing' ? 'bg-path-healing animate-pulse' : ''}
        `} />
        {phase.charAt(0).toUpperCase() + phase.slice(1)}
      </div>
    </div>
  );
};
