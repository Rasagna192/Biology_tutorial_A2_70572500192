import React from 'react';
import { Activity } from 'lucide-react';

interface ObservationPanelProps {
  logs: string[];
  phase: string;
}

export const ObservationPanel: React.FC<ObservationPanelProps> = ({ logs, phase }) => {
  return (
    <div className="glass-card rounded-xl p-4">
      <div className="flex items-center gap-2 mb-4">
        <Activity className="w-5 h-5 text-primary" />
        <h3 className="font-display font-semibold">Observation Log</h3>
      </div>
      
      <div className="space-y-2 font-mono text-sm">
        {logs.map((log, index) => (
          <div
            key={index}
            className={`
              py-1.5 px-3 rounded-lg transition-all duration-300
              ${index === logs.length - 1 ? 'bg-primary/10 text-primary' : 'text-muted-foreground'}
            `}
            style={{
              opacity: 0.5 + (index / logs.length) * 0.5,
            }}
          >
            {log}
          </div>
        ))}
      </div>
      
      {phase !== 'idle' && phase !== 'stable' && (
        <div className="mt-4 flex items-center gap-2 text-xs text-muted-foreground">
          <span className="w-2 h-2 bg-primary rounded-full animate-pulse" />
          Processing...
        </div>
      )}
    </div>
  );
};
