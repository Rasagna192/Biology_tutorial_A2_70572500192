import React from 'react';
import { Compass, TrendingUp, TrendingDown, CheckCircle } from 'lucide-react';

const rules = [
  {
    icon: Compass,
    title: 'Exploration',
    description: 'Slime spreads everywhere, filling all possible paths with faint tubes.',
    color: 'text-primary',
    bgColor: 'bg-primary/10',
  },
  {
    icon: TrendingUp,
    title: 'Reinforcement',
    description: 'Paths closer to food get more nutrient flow, becoming thicker and brighter.',
    color: 'text-secondary',
    bgColor: 'bg-secondary/10',
  },
  {
    icon: TrendingDown,
    title: 'Decay',
    description: 'Longer paths lose flow and slowly shrink—inefficient routes fade away.',
    color: 'text-muted-foreground',
    bgColor: 'bg-muted',
  },
  {
    icon: CheckCircle,
    title: 'Optimization',
    description: 'Only the most efficient path survives—the shortest route emerges naturally.',
    color: 'text-accent',
    bgColor: 'bg-accent/10',
  },
];

export const RulesSection: React.FC = () => {
  return (
    <section className="py-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
          The <span className="gradient-text">Biology</span>
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          How slime mold computes shortest paths without a brain—flow-based optimization
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {rules.map((rule, index) => (
          <div
            key={rule.title}
            className="group glass-card rounded-xl p-6 transition-all duration-300 hover:scale-105 hover:border-primary/30"
            style={{ animationDelay: `${index * 100}ms` }}
          >
            <div className={`w-12 h-12 rounded-xl ${rule.bgColor} flex items-center justify-center mb-4 group-hover:scale-110 transition-transform`}>
              <rule.icon className={`w-6 h-6 ${rule.color}`} />
            </div>
            <h3 className="font-display font-semibold text-lg mb-2">{rule.title}</h3>
            <p className="text-muted-foreground text-sm">{rule.description}</p>
          </div>
        ))}
      </div>
      
      {/* Key insight callout */}
      <div className="mt-8 p-6 glass-card rounded-xl border-primary/20 bg-primary/5 max-w-3xl mx-auto">
        <p className="text-center text-sm md:text-base">
          <span className="font-semibold text-primary">Key Insight:</span>{' '}
          <span className="text-muted-foreground">
            This is not a shortest-path algorithm—it's <em>emergent optimization</em>. 
            No global knowledge, no predefined computation—just parallel exploration and physical decay.
          </span>
        </p>
      </div>
    </section>
  );
};
