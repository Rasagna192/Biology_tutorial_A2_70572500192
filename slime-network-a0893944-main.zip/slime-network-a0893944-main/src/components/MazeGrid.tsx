import React, { useCallback, useState } from 'react';
import { Cell } from '@/types/maze';

interface MazeGridProps {
  grid: Cell[][];
  phase: string;
  onCellClick: (row: number, col: number) => void;
}

export const MazeGrid: React.FC<MazeGridProps> = ({
  grid,
  phase,
  onCellClick,
}) => {
  const [isDragging, setIsDragging] = useState(false);

  const getCellColor = (cell: Cell): string => {
    if (cell.type === 'wall') return 'hsl(var(--muted))';
    if (cell.type === 'start') return 'hsl(145 80% 45%)';
    if (cell.type === 'end') return 'hsl(0 80% 55%)';
    
    if (cell.slimeStrength > 0) {
      // Gradient from dim to bright green/yellow based on strength
      const hue = 80 + (cell.slimeStrength * 40); // 80 (yellow-green) to 120 (green)
      const lightness = 30 + (cell.slimeStrength * 30);
      const saturation = 50 + (cell.slimeStrength * 40);
      return `hsl(${hue} ${saturation}% ${lightness}%)`;
    }
    
    return 'transparent';
  };

  const getCellGlow = (cell: Cell): string => {
    if (cell.slimeStrength > 0.7) {
      return `0 0 12px hsl(100 80% 50% / ${cell.slimeStrength * 0.6})`;
    }
    if (cell.slimeStrength > 0.3) {
      return `0 0 6px hsl(100 60% 40% / ${cell.slimeStrength * 0.4})`;
    }
    return 'none';
  };

  const handleMouseDown = useCallback((row: number, col: number) => {
    if (phase !== 'setup') return;
    setIsDragging(true);
    onCellClick(row, col);
  }, [phase, onCellClick]);

  const handleMouseEnter = useCallback((row: number, col: number) => {
    if (phase !== 'setup' || !isDragging) return;
    onCellClick(row, col);
  }, [phase, isDragging, onCellClick]);

  const handleMouseUp = useCallback(() => {
    setIsDragging(false);
  }, []);

  return (
    <div 
      className="relative w-full rounded-xl border border-border overflow-hidden select-none"
      style={{
        background: 'radial-gradient(ellipse at center, hsl(200 25% 8%), hsl(200 30% 4%))',
      }}
      onMouseUp={handleMouseUp}
      onMouseLeave={handleMouseUp}
    >
      {/* Grid background */}
      <div 
        className="absolute inset-0 opacity-20"
        style={{
          backgroundImage: `
            linear-gradient(hsl(160 20% 20%) 1px, transparent 1px),
            linear-gradient(90deg, hsl(160 20% 20%) 1px, transparent 1px)
          `,
          backgroundSize: '32px 32px',
        }}
      />

      {/* Grid cells */}
      <div 
        className="relative grid gap-[1px] p-2"
        style={{
          gridTemplateColumns: `repeat(${grid[0]?.length || 20}, minmax(0, 1fr))`,
        }}
      >
        {grid.map((row, rowIdx) =>
          row.map((cell, colIdx) => (
            <div
              key={`${rowIdx}-${colIdx}`}
              className={`
                aspect-square rounded-sm transition-all duration-150
                ${phase === 'setup' ? 'cursor-pointer hover:ring-1 hover:ring-primary/50' : ''}
                ${cell.type === 'wall' ? 'border border-muted-foreground/30' : 'border border-transparent'}
              `}
              style={{
                backgroundColor: getCellColor(cell),
                boxShadow: getCellGlow(cell),
                minWidth: '20px',
                minHeight: '20px',
              }}
              onMouseDown={() => handleMouseDown(rowIdx, colIdx)}
              onMouseEnter={() => handleMouseEnter(rowIdx, colIdx)}
            >
              {cell.type === 'start' && (
                <div className="w-full h-full flex items-center justify-center text-[10px] font-bold text-white drop-shadow-lg">
                  S
                </div>
              )}
              {cell.type === 'end' && (
                <div className="w-full h-full flex items-center justify-center text-[10px] font-bold text-white drop-shadow-lg">
                  E
                </div>
              )}
            </div>
          ))
        )}
      </div>

      {/* Phase indicator */}
      <div className="absolute top-3 right-3 px-3 py-1.5 rounded-full text-xs font-medium bg-background/80 backdrop-blur-sm border border-border">
        <span className={`
          inline-block w-2 h-2 rounded-full mr-2
          ${phase === 'setup' ? 'bg-muted-foreground' : ''}
          ${phase === 'exploring' ? 'bg-primary animate-pulse' : ''}
          ${phase === 'reinforcing' ? 'bg-secondary animate-pulse' : ''}
          ${phase === 'optimizing' ? 'bg-accent animate-pulse' : ''}
          ${phase === 'complete' ? 'bg-primary' : ''}
        `} />
        {phase.charAt(0).toUpperCase() + phase.slice(1)}
      </div>

      {/* Legend */}
      <div className="absolute bottom-3 left-3 flex gap-3 text-[10px] bg-background/80 backdrop-blur-sm rounded-lg px-3 py-2 border border-border">
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-sm bg-[hsl(145_80%_45%)]" />
          <span className="text-muted-foreground">Start</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-sm bg-[hsl(0_80%_55%)]" />
          <span className="text-muted-foreground">End</span>
        </div>
        <div className="flex items-center gap-1.5">
          <div className="w-3 h-3 rounded-sm bg-muted border border-muted-foreground/30" />
          <span className="text-muted-foreground">Wall</span>
        </div>
      </div>
    </div>
  );
};
