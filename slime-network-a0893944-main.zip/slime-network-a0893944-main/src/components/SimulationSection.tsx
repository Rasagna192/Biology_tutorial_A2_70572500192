import React, { forwardRef } from 'react';
import { MazeGrid } from './MazeGrid';
import { MazeControlPanel } from './MazeControlPanel';
import { ObservationPanel } from './ObservationPanel';
import { useSlimeMoldPathfinder } from '@/hooks/useSlimeMoldPathfinder';

export const SimulationSection = forwardRef<HTMLElement>((_, ref) => {
  const { 
    state, 
    placementMode, 
    setPlacementMode, 
    setCell, 
    startSimulation, 
    reset,
    clearPaths,
  } = useSlimeMoldPathfinder();

  return (
    <section ref={ref} className="py-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
          Live <span className="gradient-text">Simulation</span>
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Watch slime mold discover the shortest path through emergent optimization
        </p>
      </div>
      
      <div className="grid lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 space-y-4">
          <MazeGrid
            grid={state.grid}
            phase={state.phase}
            onCellClick={setCell}
          />
          <MazeControlPanel
            phase={state.phase}
            placementMode={placementMode}
            hasStart={!!state.startCell}
            hasEnd={!!state.endCell}
            onSetPlacementMode={setPlacementMode}
            onStartSimulation={startSimulation}
            onClearPaths={clearPaths}
            onReset={reset}
          />
        </div>
        
        <div>
          <ObservationPanel logs={state.logs} phase={state.phase} />
          
          {state.shortestPathLength !== null && state.phase === 'complete' && (
            <div className="mt-4 p-4 glass-card rounded-xl text-center">
              <p className="text-sm text-muted-foreground mb-1">Shortest Path Length</p>
              <p className="text-3xl font-display font-bold text-primary">
                {state.shortestPathLength}
              </p>
              <p className="text-xs text-muted-foreground mt-1">steps</p>
            </div>
          )}
        </div>
      </div>
    </section>
  );
});

SimulationSection.displayName = 'SimulationSection';
