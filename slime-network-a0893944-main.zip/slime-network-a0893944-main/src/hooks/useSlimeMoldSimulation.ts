import { useState, useCallback, useRef, useEffect } from 'react';
import { Node, Path, NetworkState } from '@/types/network';

const generateId = () => Math.random().toString(36).substr(2, 9);

const distance = (n1: Node, n2: Node) => 
  Math.sqrt(Math.pow(n2.x - n1.x, 2) + Math.pow(n2.y - n1.y, 2));

export const useSlimeMoldSimulation = () => {
  const [state, setState] = useState<NetworkState>({
    nodes: [],
    paths: [],
    phase: 'idle',
    logs: ['System initialized. Add nodes to begin.'],
  });

  const animationRef = useRef<number | null>(null);

  const addLog = useCallback((message: string) => {
    setState(prev => ({
      ...prev,
      logs: [...prev.logs.slice(-9), message],
    }));
  }, []);

  const addNode = useCallback((x: number, y: number, isFood: boolean = false) => {
    const newNode: Node = {
      id: generateId(),
      x,
      y,
      isFood,
      isActive: false,
    };
    
    setState(prev => ({
      ...prev,
      nodes: [...prev.nodes, newNode],
    }));
    
    addLog(`Node added at (${Math.round(x)}, ${Math.round(y)})`);
  }, [addLog]);

  const createPaths = useCallback((nodes: Node[]): Path[] => {
    const paths: Path[] = [];
    // Connect ALL nodes - let strength determine which paths survive
    for (let i = 0; i < nodes.length; i++) {
      for (let j = i + 1; j < nodes.length; j++) {
        paths.push({
          id: generateId(),
          from: nodes[i].id,
          to: nodes[j].id,
          strength: 0.1,
          isHealing: false,
          isBroken: false,
        });
      }
    }
    return paths;
  }, []);

  const startGrowth = useCallback(() => {
    if (state.nodes.length < 2) {
      addLog('⚠️ Need at least 2 nodes to start');
      return;
    }

    const paths = createPaths(state.nodes);
    
    if (paths.length === 0) {
      addLog('⚠️ No paths could be created');
      return;
    }
    
    setState(prev => ({
      ...prev,
      paths,
      phase: 'exploring',
      nodes: prev.nodes.map(n => ({ ...n, isActive: true })),
    }));
    
    addLog(`🌱 Exploration started with ${paths.length} paths...`);
  }, [state.nodes, createPaths, addLog]);

  const breakPath = useCallback(() => {
    const strongPaths = state.paths.filter(p => p.strength > 0.4 && !p.isBroken);
    
    if (strongPaths.length === 0) {
      addLog('⚠️ No strong paths to break');
      return;
    }

    const randomPath = strongPaths[Math.floor(Math.random() * strongPaths.length)];
    
    setState(prev => ({
      ...prev,
      paths: prev.paths.map(p => 
        p.id === randomPath.id ? { ...p, isBroken: true, strength: 0 } : p
      ),
      phase: 'damaged',
    }));
    
    addLog('💥 Network path damaged!');
    
    setTimeout(() => {
      setState(prev => {
        if (prev.phase === 'damaged') {
          return { ...prev, phase: 'healing' };
        }
        return prev;
      });
      addLog('🔄 Self-healing initiated...');
    }, 1000);
  }, [state.paths, addLog]);

  const reset = useCallback(() => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }
    
    setState({
      nodes: [],
      paths: [],
      phase: 'idle',
      logs: ['System reset. Add nodes to begin.'],
    });
  }, []);

  // Simulation loop - runs when phase is active
  useEffect(() => {
    if (state.phase === 'idle' || state.phase === 'stable' || state.phase === 'damaged') {
      return;
    }

    let frameCount = 0;
    
    const simulate = () => {
      frameCount++;
      
      setState(prev => {
        // Double-check we should still be running
        if (prev.phase === 'idle' || prev.phase === 'stable' || prev.phase === 'damaged') {
          return prev;
        }

        let newPaths = [...prev.paths];
        let newPhase: NetworkState['phase'] = prev.phase;
        let newLog: string | null = null;

        if (prev.phase === 'exploring') {
          // Grow all paths gradually
          newPaths = newPaths.map(p => ({
            ...p,
            strength: Math.min(p.strength + 0.015, 0.35),
          }));

          // Check if exploration is complete
          const allExplored = newPaths.every(p => p.strength >= 0.35);
          if (allExplored) {
            newPhase = 'reinforcing';
            newLog = '📈 Reinforcing efficient paths...';
          }
        } else if (prev.phase === 'reinforcing') {
          // Reinforce short paths, decay long ones based on efficiency
          newPaths = newPaths.map(p => {
            const fromNode = prev.nodes.find(n => n.id === p.from);
            const toNode = prev.nodes.find(n => n.id === p.to);
            if (!fromNode || !toNode) return p;
            
            const dist = distance(fromNode, toNode);
            // Calculate max possible distance for normalization
            const maxDist = 700; // Approximate max canvas diagonal
            const efficiency = 1 - (dist / maxDist);
            
            // Efficient paths grow, inefficient ones decay
            const delta = efficiency > 0.6 ? 0.025 : -0.008;
            
            return {
              ...p,
              strength: Math.min(Math.max(p.strength + delta, 0.05), 1),
            };
          });

          // Check if network is stable (some paths are strong, weak ones decayed)
          const strongPaths = newPaths.filter(p => p.strength > 0.7);
          const weakPaths = newPaths.filter(p => p.strength < 0.2);
          
          if (strongPaths.length > 0 && weakPaths.length > 0) {
            newPhase = 'stable';
            newLog = '✅ Network stabilized';
          } else if (frameCount > 200) {
            // Timeout - force stable after ~3 seconds
            newPhase = 'stable';
            newLog = '✅ Network stabilized';
          }
        } else if (prev.phase === 'healing') {
          // Re-explore and strengthen alternate paths
          newPaths = newPaths.map(p => {
            if (p.isBroken) return p;
            
            const fromNode = prev.nodes.find(n => n.id === p.from);
            const toNode = prev.nodes.find(n => n.id === p.to);
            if (!fromNode || !toNode) return p;
            
            const dist = distance(fromNode, toNode);
            const maxDist = 700;
            const isEfficient = dist / maxDist < 0.5;
            
            return {
              ...p,
              strength: Math.min(p.strength + (isEfficient ? 0.03 : 0.01), 1),
              isHealing: isEfficient && p.strength < 0.8,
            };
          });

          // Check if healing is complete
          const healedCount = newPaths.filter(p => !p.isBroken && p.strength > 0.7).length;
          if (healedCount >= 1) {
            newPaths = newPaths.map(p => ({ ...p, isHealing: false }));
            newPhase = 'stable';
            newLog = '🌟 Network restored successfully!';
          } else if (frameCount > 150) {
            newPaths = newPaths.map(p => ({ ...p, isHealing: false }));
            newPhase = 'stable';
            newLog = '🌟 Network restored';
          }
        }

        return {
          ...prev,
          paths: newPaths,
          phase: newPhase,
          logs: newLog ? [...prev.logs.slice(-9), newLog] : prev.logs,
        };
      });

      animationRef.current = requestAnimationFrame(simulate);
    };

    animationRef.current = requestAnimationFrame(simulate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    };
  }, [state.phase]);

  return {
    state,
    addNode,
    startGrowth,
    breakPath,
    reset,
  };
};
