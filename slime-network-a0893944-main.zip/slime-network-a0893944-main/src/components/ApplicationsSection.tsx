import React from 'react';
import { Bot, Wifi, Map, Cpu } from 'lucide-react';

const applications = [
  {
    icon: Bot,
    title: 'Robotics Navigation',
    description: 'Autonomous robots using slime-inspired pathfinding for obstacle avoidance.',
  },
  {
    icon: Wifi,
    title: 'Network Routing',
    description: 'Internet traffic optimization through emergent, self-organizing protocols.',
  },
  {
    icon: Map,
    title: 'Urban Planning',
    description: 'Designing efficient road and rail networks—like the famous Tokyo rail experiment.',
  },
  {
    icon: Cpu,
    title: 'AI Optimization',
    description: 'Bio-inspired algorithms for solving complex computational problems.',
  },
];

export const ApplicationsSection: React.FC = () => {
  return (
    <section className="py-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
          Real-World <span className="gradient-text">Applications</span>
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          From labs to industry—slime mold intelligence inspires modern engineering
        </p>
      </div>
      
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {applications.map((app) => (
          <div
            key={app.title}
            className="group flex gap-4 p-6 glass-card rounded-xl transition-all duration-300 hover:border-primary/30"
          >
            <div className="w-14 h-14 rounded-xl bg-primary/10 flex items-center justify-center shrink-0 group-hover:bg-primary/20 transition-colors">
              <app.icon className="w-7 h-7 text-primary" />
            </div>
            <div>
              <h3 className="font-display font-semibold text-lg mb-1">{app.title}</h3>
              <p className="text-muted-foreground">{app.description}</p>
            </div>
          </div>
        ))}
      </div>

      {/* Tokyo experiment callout */}
      <div className="mt-8 p-6 glass-card rounded-xl border-secondary/20 bg-secondary/5 max-w-3xl mx-auto">
        <p className="text-center text-sm md:text-base">
          <span className="font-semibold text-secondary">Famous Experiment:</span>{' '}
          <span className="text-muted-foreground">
            In 2010, researchers placed food sources on a map of Tokyo. The slime mold grew a network 
            remarkably similar to the actual Tokyo rail system—optimized for efficiency without any planning!
          </span>
        </p>
      </div>
    </section>
  );
};
