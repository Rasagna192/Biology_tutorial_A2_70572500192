import React, { useRef } from 'react';
import { Hero } from '@/components/Hero';
import { RulesSection } from '@/components/RulesSection';
import { SimulationSection } from '@/components/SimulationSection';
import { AlgorithmSection } from '@/components/AlgorithmSection';
import { ApplicationsSection } from '@/components/ApplicationsSection';

const Index = () => {
  const simulationRef = useRef<HTMLElement>(null);

  const scrollToSimulation = () => {
    simulationRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-background">
      <Hero onScrollToSimulation={scrollToSimulation} />
      
      <main className="container mx-auto px-6">
        <RulesSection />
        <SimulationSection ref={simulationRef} />
        <AlgorithmSection />
        <ApplicationsSection />
      </main>
      
      <footer className="border-t border-border py-8 mt-16">
        <div className="container mx-auto px-6 text-center text-muted-foreground text-sm">
          <p>Slime Mold–Inspired Self-Healing Network System</p>
          <p className="mt-1 opacity-70">A biological model for resilient and adaptive networks</p>
        </div>
      </footer>
    </div>
  );
};

export default Index;
