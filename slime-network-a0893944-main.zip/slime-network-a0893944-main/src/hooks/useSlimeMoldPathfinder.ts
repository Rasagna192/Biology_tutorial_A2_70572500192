import { useState, useCallback, useRef, useEffect } from 'react';
import { Cell, MazeState, CellType, PlacementMode } from '@/types/maze';

const ROWS = 15;
const COLS = 20;

const createEmptyGrid = (): Cell[][] => {
  const grid: Cell[][] = [];
  for (let row = 0; row < ROWS; row++) {
    const rowCells: Cell[] = [];
    for (let col = 0; col < COLS; col++) {
      rowCells.push({
        row,
        col,
        type: 'empty',
        slimeStrength: 0,
        isExplored: false,
        distanceFromStart: Infinity,
      });
    }
    grid.push(rowCells);
  }
  return grid;
};

const getNeighbors = (grid: Cell[][], row: number, col: number): Cell[] => {
  const neighbors: Cell[] = [];
  const directions = [
    [-1, 0], [1, 0], [0, -1], [0, 1], // 4-directional
  ];
  
  for (const [dr, dc] of directions) {
    const newRow = row + dr;
    const newCol = col + dc;
    if (newRow >= 0 && newRow < grid.length && newCol >= 0 && newCol < grid[0].length) {
      neighbors.push(grid[newRow][newCol]);
    }
  }
  return neighbors;
};

export const useSlimeMoldPathfinder = () => {
  const [state, setState] = useState<MazeState>({
    grid: createEmptyGrid(),
    rows: ROWS,
    cols: COLS,
    startCell: null,
    endCell: null,
    phase: 'setup',
    logs: ['Click grid to place Start (green), End (red), and Walls (gray).'],
    shortestPathLength: null,
  });

  const [placementMode, setPlacementMode] = useState<PlacementMode>('wall');
  const animationRef = useRef<number | null>(null);

  const addLog = useCallback((message: string) => {
    setState(prev => ({
      ...prev,
      logs: [...prev.logs.slice(-9), message],
    }));
  }, []);

  const setCell = useCallback((row: number, col: number) => {
    setState(prev => {
      if (prev.phase !== 'setup') return prev;

      const newGrid = prev.grid.map(r => r.map(c => ({ ...c })));
      const cell = newGrid[row][col];
      
      let newStart = prev.startCell;
      let newEnd = prev.endCell;

      // Clear previous start/end if placing new one
      if (placementMode === 'start') {
        if (prev.startCell) {
          newGrid[prev.startCell.row][prev.startCell.col].type = 'empty';
        }
        cell.type = 'start';
        newStart = { row, col };
      } else if (placementMode === 'end') {
        if (prev.endCell) {
          newGrid[prev.endCell.row][prev.endCell.col].type = 'empty';
        }
        cell.type = 'end';
        newEnd = { row, col };
      } else if (placementMode === 'wall') {
        if (cell.type === 'empty') {
          cell.type = 'wall';
        }
      } else if (placementMode === 'erase') {
        if (cell.type === 'wall') {
          cell.type = 'empty';
        } else if (cell.type === 'start') {
          cell.type = 'empty';
          newStart = null;
        } else if (cell.type === 'end') {
          cell.type = 'empty';
          newEnd = null;
        }
      }

      return {
        ...prev,
        grid: newGrid,
        startCell: newStart,
        endCell: newEnd,
      };
    });
  }, [placementMode]);

  const startSimulation = useCallback(() => {
    if (!state.startCell || !state.endCell) {
      addLog('⚠️ Place both Start and End points first!');
      return;
    }

    // Initialize slime at start
    setState(prev => {
      const newGrid = prev.grid.map(r => r.map(c => ({ 
        ...c, 
        slimeStrength: 0, 
        isExplored: false,
        distanceFromStart: Infinity,
      })));
      
      if (prev.startCell) {
        newGrid[prev.startCell.row][prev.startCell.col].slimeStrength = 1;
        newGrid[prev.startCell.row][prev.startCell.col].isExplored = true;
        newGrid[prev.startCell.row][prev.startCell.col].distanceFromStart = 0;
      }

      return {
        ...prev,
        grid: newGrid,
        phase: 'exploring',
        logs: [...prev.logs.slice(-9), '🌱 Slime mold begins exploration...'],
      };
    });
  }, [state.startCell, state.endCell, addLog]);

  const reset = useCallback(() => {
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }

    setState({
      grid: createEmptyGrid(),
      rows: ROWS,
      cols: COLS,
      startCell: null,
      endCell: null,
      phase: 'setup',
      logs: ['System reset. Place Start, End, and Walls.'],
      shortestPathLength: null,
    });
  }, []);

  const clearPaths = useCallback(() => {
    if (state.phase !== 'setup' && state.phase !== 'complete') return;
    
    if (animationRef.current) {
      cancelAnimationFrame(animationRef.current);
      animationRef.current = null;
    }

    setState(prev => ({
      ...prev,
      grid: prev.grid.map(r => r.map(c => ({
        ...c,
        slimeStrength: 0,
        isExplored: false,
        distanceFromStart: Infinity,
      }))),
      phase: 'setup',
      logs: [...prev.logs.slice(-9), 'Paths cleared. Ready to run again.'],
      shortestPathLength: null,
    }));
  }, [state.phase]);

  // Simulation loop
  useEffect(() => {
    if (state.phase === 'setup' || state.phase === 'complete') {
      return;
    }

    let frameCount = 0;
    let foundEnd = false;

    const simulate = () => {
      frameCount++;

      setState(prev => {
        if (prev.phase === 'setup' || prev.phase === 'complete') {
          return prev;
        }

        const newGrid = prev.grid.map(r => r.map(c => ({ ...c })));
        let newPhase: MazeState['phase'] = prev.phase;
        let newLog: string | null = null;
        let pathLength: number | null = prev.shortestPathLength;

        if (prev.phase === 'exploring') {
          // Spread slime to neighbors (BFS-like expansion)
          let expanded = false;
          
          for (let row = 0; row < prev.rows; row++) {
            for (let col = 0; col < prev.cols; col++) {
              const cell = prev.grid[row][col];
              if (cell.isExplored && cell.type !== 'wall') {
                const neighbors = getNeighbors(prev.grid, row, col);
                for (const neighbor of neighbors) {
                  if (!neighbor.isExplored && neighbor.type !== 'wall') {
                    const newDist = cell.distanceFromStart + 1;
                    if (newDist < newGrid[neighbor.row][neighbor.col].distanceFromStart) {
                      newGrid[neighbor.row][neighbor.col].isExplored = true;
                      newGrid[neighbor.row][neighbor.col].slimeStrength = 0.3;
                      newGrid[neighbor.row][neighbor.col].distanceFromStart = newDist;
                      expanded = true;

                      // Check if we reached the end
                      if (neighbor.type === 'end') {
                        foundEnd = true;
                        pathLength = newDist;
                      }
                    }
                  }
                }
              }
            }
          }

          if (foundEnd) {
            newPhase = 'reinforcing';
            newLog = '🎯 Food source found! Reinforcing efficient paths...';
          } else if (!expanded) {
            newPhase = 'complete';
            newLog = '❌ No path exists to the food source!';
          }
        } else if (prev.phase === 'reinforcing') {
          // Strengthen paths based on distance to end
          const endCell = prev.endCell;
          if (!endCell) return prev;

          const endDist = newGrid[endCell.row][endCell.col].distanceFromStart;
          
          for (let row = 0; row < prev.rows; row++) {
            for (let col = 0; col < prev.cols; col++) {
              const cell = newGrid[row][col];
              if (cell.isExplored && cell.type !== 'wall') {
                // Calculate if this cell is on an efficient path
                const distFromStart = cell.distanceFromStart;
                
                // Cells on shortest path have distFromStart close to optimal
                const optimalDist = distFromStart;
                const efficiency = 1 - (optimalDist / (endDist + 1));
                
                // Reinforce based on efficiency
                const targetStrength = Math.max(0.2, efficiency);
                cell.slimeStrength = Math.min(
                  cell.slimeStrength + (targetStrength - cell.slimeStrength) * 0.1,
                  1
                );
              }
            }
          }

          if (frameCount > 60) {
            newPhase = 'optimizing';
            newLog = '🔬 Optimizing... weak paths decaying...';
          }
        } else if (prev.phase === 'optimizing') {
          // Decay weak paths, keep only shortest
          const endCell = prev.endCell;
          const startCell = prev.startCell;
          if (!endCell || !startCell) return prev;

          // Build shortest path by backtracking from end
          const shortestPath = new Set<string>();
          let current = endCell;
          
          while (current.row !== startCell.row || current.col !== startCell.col) {
            shortestPath.add(`${current.row}-${current.col}`);
            const neighbors = getNeighbors(newGrid, current.row, current.col);
            let minDist = Infinity;
            let nextCell = current;
            
            for (const neighbor of neighbors) {
              if (neighbor.isExplored && neighbor.distanceFromStart < minDist) {
                minDist = neighbor.distanceFromStart;
                nextCell = { row: neighbor.row, col: neighbor.col };
              }
            }
            
            if (nextCell.row === current.row && nextCell.col === current.col) break;
            current = nextCell;
          }
          shortestPath.add(`${startCell.row}-${startCell.col}`);

          // Decay non-shortest paths
          for (let row = 0; row < prev.rows; row++) {
            for (let col = 0; col < prev.cols; col++) {
              const cell = newGrid[row][col];
              const key = `${row}-${col}`;
              
              if (shortestPath.has(key)) {
                // On shortest path - strengthen
                cell.slimeStrength = Math.min(cell.slimeStrength + 0.05, 1);
              } else if (cell.isExplored) {
                // Not on shortest path - decay
                cell.slimeStrength = Math.max(cell.slimeStrength - 0.02, 0);
              }
            }
          }

          // Check if optimization is complete
          const nonPathCells = newGrid.flat().filter(
            c => c.isExplored && c.slimeStrength > 0.1 && !shortestPath.has(`${c.row}-${c.col}`)
          );

          if (nonPathCells.length === 0 || frameCount > 200) {
            newPhase = 'complete';
            newLog = `✅ Shortest path found! Length: ${pathLength} steps`;
          }
        }

        return {
          ...prev,
          grid: newGrid,
          phase: newPhase,
          logs: newLog ? [...prev.logs.slice(-9), newLog] : prev.logs,
          shortestPathLength: pathLength,
        };
      });

      if (state.phase !== 'complete') {
        animationRef.current = requestAnimationFrame(simulate);
      }
    };

    animationRef.current = requestAnimationFrame(simulate);

    return () => {
      if (animationRef.current) {
        cancelAnimationFrame(animationRef.current);
        animationRef.current = null;
      }
    };
  }, [state.phase]);

  return {
    state,
    placementMode,
    setPlacementMode,
    setCell,
    startSimulation,
    reset,
    clearPaths,
  };
};
