import React from 'react';
import { Button } from '@/components/ui/button';
import { Play, RotateCcw, Square, Circle, Eraser, Target } from 'lucide-react';
import { PlacementMode } from '@/types/maze';

interface MazeControlPanelProps {
  phase: string;
  placementMode: PlacementMode;
  hasStart: boolean;
  hasEnd: boolean;
  onSetPlacementMode: (mode: PlacementMode) => void;
  onStartSimulation: () => void;
  onClearPaths: () => void;
  onReset: () => void;
}

export const MazeControlPanel: React.FC<MazeControlPanelProps> = ({
  phase,
  placementMode,
  hasStart,
  hasEnd,
  onSetPlacementMode,
  onStartSimulation,
  onClearPaths,
  onReset,
}) => {
  const canStart = phase === 'setup' && hasStart && hasEnd;
  const isRunning = phase !== 'setup' && phase !== 'complete';
  
  return (
    <div className="flex flex-col gap-4 p-4 bg-card rounded-xl border border-border">
      {/* Placement mode buttons */}
      <div className="space-y-2">
        <span className="text-xs font-medium text-muted-foreground uppercase tracking-wider">
          Placement Mode
        </span>
        <div className="flex flex-wrap gap-2">
          <Button
            variant={placementMode === 'start' ? 'slime' : 'control'}
            size="sm"
            onClick={() => onSetPlacementMode('start')}
            disabled={isRunning}
            className="gap-1.5"
          >
            <Circle className="w-3 h-3 fill-[hsl(145_80%_45%)] text-[hsl(145_80%_45%)]" />
            Start
          </Button>
          
          <Button
            variant={placementMode === 'end' ? 'danger' : 'control'}
            size="sm"
            onClick={() => onSetPlacementMode('end')}
            disabled={isRunning}
            className="gap-1.5"
          >
            <Target className="w-3 h-3 text-destructive" />
            End
          </Button>
          
          <Button
            variant={placementMode === 'wall' ? 'secondary' : 'control'}
            size="sm"
            onClick={() => onSetPlacementMode('wall')}
            disabled={isRunning}
            className="gap-1.5"
          >
            <Square className="w-3 h-3" />
            Wall
          </Button>
          
          <Button
            variant={placementMode === 'erase' ? 'outline' : 'control'}
            size="sm"
            onClick={() => onSetPlacementMode('erase')}
            disabled={isRunning}
            className="gap-1.5"
          >
            <Eraser className="w-3 h-3" />
            Erase
          </Button>
        </div>
      </div>

      {/* Action buttons */}
      <div className="flex flex-wrap gap-3 pt-2 border-t border-border">
        <Button
          variant="slime"
          size="default"
          onClick={onStartSimulation}
          disabled={!canStart || isRunning}
          className="flex-1"
        >
          <Play className="w-4 h-4" />
          {isRunning ? 'Running...' : 'Start Growth'}
        </Button>
        
        <Button
          variant="control"
          size="default"
          onClick={onClearPaths}
          disabled={isRunning}
        >
          Clear Paths
        </Button>
        
        <Button
          variant="control"
          size="default"
          onClick={onReset}
        >
          <RotateCcw className="w-4 h-4" />
          Reset All
        </Button>
      </div>

      {/* Status hint */}
      {phase === 'setup' && !hasStart && !hasEnd && (
        <p className="text-xs text-muted-foreground">
          Place a <span className="text-[hsl(145_80%_45%)]">Start</span> point and an <span className="text-destructive">End</span> point, then add walls to create a maze.
        </p>
      )}
      {phase === 'setup' && hasStart && !hasEnd && (
        <p className="text-xs text-muted-foreground">
          Now place the <span className="text-destructive">End</span> point (food source).
        </p>
      )}
      {phase === 'setup' && hasStart && hasEnd && (
        <p className="text-xs text-muted-foreground">
          Ready! Add walls or click <span className="text-primary">Start Growth</span> to run.
        </p>
      )}
    </div>
  );
};
