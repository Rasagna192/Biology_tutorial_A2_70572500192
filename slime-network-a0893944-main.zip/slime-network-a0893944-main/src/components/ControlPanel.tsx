import React from 'react';
import { Button } from '@/components/ui/button';
import { Plus, Play, X, RotateCcw } from 'lucide-react';

interface ControlPanelProps {
  phase: string;
  nodeCount: number;
  onStartGrowth: () => void;
  onBreakPath: () => void;
  onReset: () => void;
}

export const ControlPanel: React.FC<ControlPanelProps> = ({
  phase,
  nodeCount,
  onStartGrowth,
  onBreakPath,
  onReset,
}) => {
  const canStart = phase === 'idle' && nodeCount >= 2;
  const canBreak = phase === 'stable';
  
  return (
    <div className="flex flex-wrap gap-3 p-4 bg-card rounded-xl border border-border">
      <div className="flex items-center gap-2 text-sm text-muted-foreground mr-auto">
        <Plus className="w-4 h-4" />
        <span>Click canvas to add nodes ({nodeCount})</span>
      </div>
      
      <Button
        variant="slime"
        size="default"
        onClick={onStartGrowth}
        disabled={!canStart}
      >
        <Play className="w-4 h-4" />
        Start Growth
      </Button>
      
      <Button
        variant="danger"
        size="default"
        onClick={onBreakPath}
        disabled={!canBreak}
      >
        <X className="w-4 h-4" />
        Break Path
      </Button>
      
      <Button
        variant="control"
        size="default"
        onClick={onReset}
      >
        <RotateCcw className="w-4 h-4" />
        Reset
      </Button>
    </div>
  );
};
