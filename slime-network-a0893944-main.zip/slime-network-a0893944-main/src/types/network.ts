export interface Node {
  id: string;
  x: number;
  y: number;
  isFood: boolean;
  isActive: boolean;
}

export interface Path {
  id: string;
  from: string;
  to: string;
  strength: number;
  isHealing: boolean;
  isBroken: boolean;
}

export interface NetworkState {
  nodes: Node[];
  paths: Path[];
  phase: 'idle' | 'exploring' | 'reinforcing' | 'stable' | 'damaged' | 'healing';
  logs: string[];
}
