import React from 'react';
import { Button } from '@/components/ui/button';
import { HeroBackground } from './HeroBackground';
import { ArrowDown } from 'lucide-react';

interface HeroProps {
  onScrollToSimulation: () => void;
}

export const Hero: React.FC<HeroProps> = ({ onScrollToSimulation }) => {
  return (
    <section className="relative min-h-[90vh] flex items-center justify-center overflow-hidden">
      <HeroBackground />
      
      {/* Gradient overlay */}
      <div className="absolute inset-0 bg-gradient-to-b from-transparent via-background/50 to-background pointer-events-none" />
      
      <div className="relative z-10 text-center px-6 max-w-4xl mx-auto">
        <div className="mb-6 inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/20 text-primary text-sm">
          <span className="w-2 h-2 rounded-full bg-primary animate-pulse" />
          Bio-Inspired Computing
        </div>
        
        <h1 className="text-4xl md:text-6xl lg:text-7xl font-display font-bold mb-6 leading-tight">
          Slime Mold–Inspired{' '}
          <span className="gradient-text">Shortest Path</span>{' '}
          Finder
        </h1>
        
        <p className="text-lg md:text-xl text-muted-foreground mb-4 max-w-2xl mx-auto">
          Shortest path discovery without algorithms or a brain
        </p>
        
        <p className="text-sm md:text-base text-muted-foreground/80 mb-10 max-w-xl mx-auto">
          Watch how nature solves complex optimization problems through emergent behavior
        </p>
        
        <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            variant="slime" 
            size="xl"
            onClick={onScrollToSimulation}
          >
            Run Simulation
            <ArrowDown className="w-5 h-5 ml-1 animate-bounce" />
          </Button>
          
          <Button 
            variant="outline" 
            size="xl"
            onClick={onScrollToSimulation}
          >
            Learn More
          </Button>
        </div>
      </div>
      
      {/* Bottom fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-background to-transparent" />
    </section>
  );
};
