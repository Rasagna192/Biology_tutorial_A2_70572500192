import React from 'react';

const steps = [
  { step: 1, text: 'Initialize slime at start node', phase: 'init' },
  { step: 2, text: 'Spread slime to all neighboring cells', phase: 'explore' },
  { step: 3, text: 'Assign flow value to each path', phase: 'explore' },
  { step: 4, text: 'Increase flow on paths closer to food', phase: 'reinforce' },
  { step: 5, text: 'Reduce flow on longer paths', phase: 'decay' },
  { step: 6, text: 'Remove paths below threshold', phase: 'decay' },
  { step: 7, text: 'Remaining path is shortest', phase: 'complete' },
];

const comparison = [
  { slime: 'Parallel exploration', traditional: 'Sequential search' },
  { slime: 'No global knowledge', traditional: 'Global cost table' },
  { slime: 'Physical decay', traditional: 'Mathematical elimination' },
  { slime: 'Emergent result', traditional: 'Predefined computation' },
];

export const AlgorithmSection: React.FC = () => {
  return (
    <section className="py-16">
      <div className="text-center mb-12">
        <h2 className="text-3xl md:text-4xl font-display font-bold mb-4">
          The <span className="gradient-text">Algorithm</span>
        </h2>
        <p className="text-muted-foreground max-w-2xl mx-auto">
          Bio-inspired, not classical—this mimics tube adaptation, not graph search
        </p>
      </div>
      
      <div className="grid lg:grid-cols-2 gap-12">
        {/* Steps */}
        <div>
          <h3 className="font-display font-semibold text-lg mb-6">How It Works</h3>
          <div className="relative">
            {/* Vertical line */}
            <div className="absolute left-6 top-0 bottom-0 w-px bg-gradient-to-b from-primary via-secondary to-accent" />
            
            <div className="space-y-3">
              {steps.map(({ step, text, phase }) => (
                <div 
                  key={step}
                  className="relative flex items-center gap-6 pl-14"
                >
                  <div 
                    className={`
                      absolute left-3 w-6 h-6 rounded-full flex items-center justify-center text-xs font-bold
                      ${phase === 'init' ? 'bg-muted text-foreground' : ''}
                      ${phase === 'explore' ? 'bg-primary text-primary-foreground' : ''}
                      ${phase === 'reinforce' ? 'bg-secondary text-secondary-foreground' : ''}
                      ${phase === 'decay' ? 'bg-muted-foreground text-background' : ''}
                      ${phase === 'complete' ? 'bg-accent text-accent-foreground' : ''}
                    `}
                  >
                    {step}
                  </div>
                  <div className="py-2.5 px-4 glass-card rounded-lg flex-1">
                    <code className="text-sm">{text}</code>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Comparison table */}
        <div>
          <h3 className="font-display font-semibold text-lg mb-6">Slime Mold vs Dijkstra</h3>
          <div className="glass-card rounded-xl overflow-hidden">
            <div className="grid grid-cols-2 bg-muted/50">
              <div className="p-4 font-semibold text-sm border-b border-border">Slime Mold</div>
              <div className="p-4 font-semibold text-sm border-b border-l border-border">Traditional Algorithm</div>
            </div>
            {comparison.map(({ slime, traditional }, index) => (
              <div key={index} className="grid grid-cols-2">
                <div className={`p-4 text-sm text-primary ${index < comparison.length - 1 ? 'border-b border-border' : ''}`}>
                  {slime}
                </div>
                <div className={`p-4 text-sm text-muted-foreground border-l ${index < comparison.length - 1 ? 'border-b border-border' : ''}`}>
                  {traditional}
                </div>
              </div>
            ))}
          </div>
          
          <p className="mt-4 text-sm text-muted-foreground">
            💡 <span className="font-medium text-foreground">Viva tip:</span> Emphasize that slime mold achieves the same result through <em>distributed, local decisions</em>—no central controller needed.
          </p>
        </div>
      </div>
    </section>
  );
};
